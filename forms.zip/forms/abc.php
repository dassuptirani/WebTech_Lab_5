<?php

	$uname			=$_REQUEST['Uname'];
	$password		=$_REQUEST['Pword'];
	$DateOfBirth	=$_REQUEST['date'];
	$Add			=$_REQUEST['add'];
    $Dept			=$_REQUEST['dept'];
    $Gender			=$_REQUEST['gender'];
	
	echo $uname ;
	echo $password ;
	echo $DateOfBirth ;
	echo $Add ;
	echo $Dept ;
	echo $Gender ;
	

?>